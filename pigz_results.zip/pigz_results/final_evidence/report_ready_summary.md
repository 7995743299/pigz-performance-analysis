# Pigz Complete Experiment Report-Ready Summary

## Task 1: Best Thread Per File

| Mode | File | Best Threads | Avg Time (s) | Compression Ratio (%) | Max RSS (KB) |
|---|---|---:|---:|---:|---:|
| full | 10MB | 16 | 0.057 | 76.08 | 13739 |
| full | 100MB | 16 | 0.700 | 76.08 | 13653 |
| full | 1GB | 16 | 9.280 | 76.08 | 13739 |
| full | 5GB | 16 | 50.310 | 76.08 | 13611 |

## Task 2: Hotspot Evidence

| File | Threads | Type | Top Hotspot | Percent of Program |
|---|---:|---|---|---:|
| 10MB | 1 | inclusive | 0x0000000000023340 [/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2] |  |
| 10MB | 1 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 10MB | 2 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 10MB | 2 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 10MB | 4 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 10MB | 4 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 10MB | 8 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 10MB | 8 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 10MB | 16 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 10MB | 16 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 100MB | 1 | inclusive | 0x0000000000023340 [/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2] |  |
| 100MB | 1 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 100MB | 2 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 100MB | 2 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 100MB | 4 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 100MB | 4 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 100MB | 8 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 100MB | 8 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 100MB | 16 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 100MB | 16 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 1GB | 1 | inclusive | 0x0000000000023340 [/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2] |  |
| 1GB | 1 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 1GB | 2 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 1GB | 2 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 1GB | 4 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 1GB | 4 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 1GB | 8 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 1GB | 8 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 1GB | 16 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 1GB | 16 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 5GB | 1 | inclusive | 0x0000000000023340 [/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2] |  |
| 5GB | 1 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 5GB | 2 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 5GB | 2 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 5GB | 4 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 5GB | 4 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 5GB | 8 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 5GB | 8 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |
| 5GB | 16 | inclusive | start_thread [/usr/lib/x86_64-linux-gnu/libc.so.6] |  |
| 5GB | 16 | self | 0x000000000000a1f0 [/usr/lib/x86_64-linux-gnu/libz.so.1.3.1] |  |

## Interpretation Checklist

- Execution time should generally decrease as thread count increases for larger files.
- Small files may not improve as much because thread setup/coordination overhead is more visible.
- If gains flatten after 8 or 16 threads, that supports diminishing returns.
- Stable compression ratio means thread count changes speed, not output efficiency.
- Low iowait plus high user CPU suggests CPU-bound compression.
- Callgrind hotspots should mainly appear in zlib/libz deflate, checksum, and memory movement routines.
